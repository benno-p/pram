var doc = new jsPDF('landscape');
doc.text('Hello landscape world!', 20, 20);